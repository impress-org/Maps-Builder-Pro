<?php
/**
 * Add extra marker markup in pro via "gmb_extra_markers" hook
 *
 * @package   gmb
 * @license   GPL-2.0+
 * @link
 * @copyright 2016 WordImpress
 */
?>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink-blank.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink-dot.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerA.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerB.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerC.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerD.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerE.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerF.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerG.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerH.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerI.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerJ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerK.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerL.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerM.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerN.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerO.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerP.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerQ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerR.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerS.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerT.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerU.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/pink_MarkerV.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple-blank.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple-dot.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerA.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerB.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerC.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerD.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerE.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerF.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerG.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerH.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerI.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerJ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerK.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerL.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerM.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerN.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerO.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerP.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerQ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerR.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerS.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerT.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerU.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerV.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerW.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerX.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerY.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/purple_MarkerZ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red-blank.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red-dot.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerA.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerB.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerC.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerD.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerE.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerF.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerG.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerH.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerI.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerJ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerK.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerL.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerM.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerN.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerO.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerP.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerQ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerR.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerS.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerT.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerU.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerV.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerW.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerX.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerY.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/red_MarkerZ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow-blank.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow-dot.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerA.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerB.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerC.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerD.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerE.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerF.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerG.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerH.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerI.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerJ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerK.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerL.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerM.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerN.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerO.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerP.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerQ.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerR.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerS.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerT.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerU.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerV.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerW.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerX.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerY.png' ?>" alt=""></a>
</li>
<li>
	<a href="#" class="maps-icon"><img src="<?php echo GMB_PLUGIN_URL . 'assets/img/default-icons/yellow_MarkerZ.png' ?>" alt=""></a>
</li>