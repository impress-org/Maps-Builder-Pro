<?php

/**
 * GMB_Shortcode_Generator class.
 *
 * $current_user->IDAdds a TinyMCE button that's clickable
 *
 * @since      2.0
 */
class GMB_Shortcode_Generator extends Google_Maps_Builder_Core_Shortcode_Generator {


}